<script>
  import Todos from '$lib/components/Todos.svelte';
</script>

<main>
  <Todos />
</main>